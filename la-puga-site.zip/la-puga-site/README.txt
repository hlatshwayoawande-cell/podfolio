LA PUGA website

FILES
index.html      the page (home)
css/style.css   styling
js/main.js      menu, filters, viewer
images/         portfolio images
favicon.svg     tab icon
robots.txt      search engine rules
server.js       tiny server (only needed on hosts that ask for a start command)
package.json    tells Render/Node hosts how to start it
render.yaml     one-click Render setup
.gitignore      for GitHub

KEEP THE FOLDERS EXACTLY AS THEY ARE.

RENDER (Web Service)
1. Upload ALL files to a GitHub repo (index.html, server.js and package.json must be at the top level, not inside another folder).
2. Render -> New -> Web Service -> pick the repo.
3. Language: Node | Build command: npm install | Start command: npm start
4. Deploy.

NETLIFY / CLOUDFLARE PAGES (no server needed)
Drag the unzipped folder into app.netlify.com/drop (or Cloudflare Pages -> Direct upload).
