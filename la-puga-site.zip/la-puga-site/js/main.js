const $=id=>document.getElementById(id);
const items=[...document.querySelectorAll(".item")];
let filter="All",cur=items,idx=0;
const nav=$("nav"),bg=$("burger");
function menu(o){nav.classList.toggle("open",o);bg.setAttribute("aria-expanded",o);bg.textContent=o?"\u2715":"\u2630"}
bg.onclick=()=>menu(!nav.classList.contains("open"));
document.querySelectorAll("nav a").forEach(a=>a.onclick=()=>menu(false));
document.addEventListener("click",e=>{if(!nav.contains(e.target))menu(false)});
const cats=["All",...new Set(items.map(i=>i.dataset.cat))];
function renderFilters(){
  $("filters").innerHTML="";
  cats.forEach(c=>{const b=document.createElement("button");b.textContent=c;b.className=c===filter?"on":"";b.setAttribute("aria-pressed",c===filter);
    b.onclick=()=>{filter=c;items.forEach(i=>i.hidden=!(c==="All"||i.dataset.cat===c));cur=items.filter(i=>!i.hidden);renderFilters()};$("filters").appendChild(b)});
}
items.forEach(it=>it.querySelector(".card").onclick=()=>show(cur.indexOf(it)));
function show(i){
  idx=(i+cur.length)%cur.length;const it=cur[idx],im=it.querySelector("img");
  $("lbc").textContent=it.dataset.cat;$("lbt").textContent=it.dataset.title;$("lbi").src=im.src;$("lbi").alt=it.dataset.title;$("lbd").textContent=it.dataset.desc;
  $("lbk").textContent=(idx+1)+" / "+cur.length;$("lb").scrollTop=0;
  $("lb").classList.add("show");document.body.style.overflow="hidden";
  document.querySelector(".lbn").style.display=cur.length>1?"flex":"none";
}
function closeLb(){$("lb").classList.remove("show");document.body.style.overflow=""}
$("lbx").onclick=closeLb;$("lbp").onclick=()=>show(idx-1);$("lbnx").onclick=()=>show(idx+1);
document.addEventListener("keydown",e=>{if(!$("lb").classList.contains("show"))return;
  if(e.key==="Escape")closeLb();if(e.key==="ArrowLeft")show(idx-1);if(e.key==="ArrowRight")show(idx+1)});
let sx=null;$("lb").addEventListener("touchstart",e=>{sx=e.touches[0].clientX},{passive:true});
$("lb").addEventListener("touchend",e=>{if(sx===null)return;const d=e.changedTouches[0].clientX-sx;sx=null;if(Math.abs(d)>70)show(idx+(d<0?1:-1))},{passive:true});
renderFilters();