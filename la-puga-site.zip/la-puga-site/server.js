// Tiny static file server (no dependencies). Used when a host asks for a start command.
const http = require("http"), fs = require("fs"), path = require("path");
const root = __dirname, port = process.env.PORT || 3000;
const types = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".jpg":"image/jpeg",".jpeg":"image/jpeg",".png":"image/png",".svg":"image/svg+xml",".txt":"text/plain; charset=utf-8",".xml":"application/xml",".ico":"image/x-icon"};
http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p.endsWith("/")) p += "index.html";
  const file = path.join(root, path.normalize(p));
  const blocked = /(^|[\\/])(server\.js|package\.json|render\.yaml|README\.txt|\.git)/i.test(path.relative(root, file));
  if (!file.startsWith(root) || blocked) { res.writeHead(404); return res.end("Not found"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, {"Content-Type":"text/plain"}); return res.end("Not found"); }
    res.writeHead(200, {"Content-Type": types[path.extname(file).toLowerCase()] || "application/octet-stream", "Cache-Control": path.extname(file) === ".html" ? "no-cache" : "public, max-age=86400"});
    res.end(data);
  });
}).listen(port, () => console.log("LA PUGA running on port " + port));
